Welcome: <?php echo htmlentities($_SESSION['user']['username'], ENT_QUOTES, 'UTF-8'); ?> 
| <a href="index.php">Index</a>
| <a href="memberlist.php">Memberlist</a>
| <a href="edit_account.php">Edit Account</a>
| <a href="logout.php">Logout</a>